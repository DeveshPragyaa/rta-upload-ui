'use client'

import { useState, ChangeEvent } from 'react'
import { Button } from "@/components/ui/button"
import { Loader2 } from 'lucide-react'

interface UploadResponse {
  success: boolean
  message: string
  urls?: string[] // Add URLs if successful
}

export function Home() {
  const [files, setFiles] = useState<File[]>([])
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)
  const [uploadedUrls, setUploadedUrls] = useState<string[] | null>(null)

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files))
      setError(null)
    }
  }

  const handleUpload = async (): Promise<void> => {
    if (files.length === 0) {
      setError('Please select at least one file')
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const formData = new FormData()
      files.forEach(file => {
        formData.append('files', file)
      })

      const response = await fetch('http://localhost:8000/upload', {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        throw new Error('Upload failed')
      }

      const data: UploadResponse = await response.json()
      console.log('Upload successful:', data)
      setUploadedUrls(data.files || [])

      setFiles([])

      const fileInput = document.getElementById('file-input') as HTMLInputElement
      if (fileInput) fileInput.value = ''

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred')
      console.error('Upload error:', err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-black text-white">
      <div className="w-full max-w-md space-y-4">
        <h1 className="text-2xl font-bold text-center">
          Upload Files to VoiceLens
        </h1>

        <input
          type="file"
          id="file-input"
          multiple
          onChange={handleFileChange}
          className="hidden"
        />

        <div className="flex flex-col items-center gap-4">
          <Button
            onClick={() => document.getElementById('file-input')?.click()}
            variant="outline"
            className="w-full text-white border-white hover:bg-gray-700"
          >
            Select Files
          </Button>

          {files.length > 0 && (
            <div className="w-full text-sm">
              Selected: {files.length} {files.length === 1 ? 'file' : 'files'}
            </div>
          )}

          <Button 
            onClick={handleUpload} 
            className="w-full text-white border-white hover:bg-gray-700"
            disabled={isLoading || files.length === 0}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Uploading...
              </>
            ) : (
              'Upload to VoiceLens'
            )}
          </Button>

          {error && (
            <div className="text-sm text-red-500">
              {error}
            </div>
          )}

          {uploadedUrls && uploadedUrls.length > 0 && (
            <div className="mt-4 text-sm text-green-500">
              <strong>Upload Successful!</strong>
              <ul>
                {uploadedUrls.map((url, index) => (
                  <li key={index}><a href={url} target="_blank" rel="noopener noreferrer">{url}</a></li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Home;
